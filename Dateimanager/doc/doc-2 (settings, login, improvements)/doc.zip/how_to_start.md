Da die .bat Datei nicht über Email verschickbar ist, gibt es nur die möglichkeit die .html datei direkt zu öffnen, das tun Sie so:

- Öffnen Sie die Datei templates/index.html direkt in Ihrem Webbrowser.
- Dies können Sie tun, indem Sie die Datei per Drag & Drop in das Browserfenster ziehen oder über das Menü "Datei" -> "Datei öffnen" auswählen.
- Die Dokumentation ist mit allen gängigen Webbrowsern kompatibel.